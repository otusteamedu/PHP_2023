<?php
namespace App\Files\Domain;

class UploadedFile extends File
{
    public function __construct(
        private string $name,
        private string $path,
        private string $type,
    )
    {
    }

    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getPath(): string
    {
        return $this->path;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return $this->type;
    }
}