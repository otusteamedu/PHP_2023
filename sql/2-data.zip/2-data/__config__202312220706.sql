INSERT INTO public."_config" (id,coefficient) VALUES
	 (1,0.88);
