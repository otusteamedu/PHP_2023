<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'index', '_controller' => ['App\\Common\\Infrastructure\\Controller', 'index']], null, ['GET' => 0], null, false, false, null]],
        '/order' => [
            [['_route' => 'order_list', '_controller' => ['App\\Ads\\Infrastructure\\Controller', 'index']], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'order_post', '_controller' => ['App\\Ads\\Infrastructure\\Controller', 'create']], null, ['POST' => 0], null, false, false, null],
        ],
    ],
    [ // $regexpList
    ],
    [ // $dynamicRoutes
    ],
    null, // $checkCondition
];
