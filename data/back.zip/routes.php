<?php

use App\Ads\Infrastructure\Controller;
use Pecee\SimpleRouter\SimpleRouter;

SimpleRouter::post('/order', [Controller::class, 'create']);
SimpleRouter::get('/order', [Controller::class, 'index']);
SimpleRouter::get('/order/{id}', [Controller::class, 'getById']);