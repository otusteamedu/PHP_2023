<?php

namespace App\Ads\Infrastructure;

use App\Files\Domain\UploadedFile;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Mapping\ClassMetadata;


class Request
{
    public string $name;
    public string $email;
    public string $title;
    public string $comment;
    public UploadedFile $photo;

    public static function loadValidatorMetadata(ClassMetadata $metadata): void
    {
        $metadata->addPropertyConstraint('name', new Assert\NotBlank());
        $metadata->addPropertyConstraint('name', new Assert\Length(null, 3, 128));

        $metadata->addPropertyConstraint('email', new Assert\Email());

        $metadata->addPropertyConstraint('title', new Assert\NotBlank());
        $metadata->addPropertyConstraint('title', new Assert\Length(null, 3, 128));

        $metadata->addPropertyConstraint('comment', new Assert\NotBlank());
        $metadata->addPropertyConstraint('comment', new Assert\Length(null, 3, 128));

        $metadata->addPropertyConstraint('photo', new Assert\Required());
        $metadata->addPropertyConstraint('photo', new Assert\Image());
    }
}