<?php
namespace App\Common\Infrastructure;

use App\Ads\Infrastructure\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Attribute\MapRequestPayload;

#use Symfony\Component\HttpFoundation\Request;
class Controller
{
    public function index(): Response
    {
        return new Response('index');
    }
}