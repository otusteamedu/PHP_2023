INSERT INTO public.dict_session (id,"text") VALUES
	 (1,'утро'),
	 (2,'день'),
	 (3,'вечер'),
	 (4,'ночь');
