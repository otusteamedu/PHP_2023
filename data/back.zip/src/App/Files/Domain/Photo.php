<?php
namespace App\Files\Domain;

class Photo extends File
{
}