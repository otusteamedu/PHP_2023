INSERT INTO public.dict_hall (id,"name",seating_capacity) VALUES
	 (1,'@залМалый',12),
	 (2,'@залОсновной',16),
	 (3,'@залБольшой',304);
