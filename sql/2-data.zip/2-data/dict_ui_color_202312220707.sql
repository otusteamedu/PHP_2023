INSERT INTO public.dict_ui_color (id,"name") VALUES
	 (1,'white'),
	 (2,'red'),
	 (3,'green'),
	 (4,'blue'),
	 (5,'yellow');
