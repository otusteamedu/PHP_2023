INSERT INTO public.dict_status (id,"name") VALUES
	 (1,'свободен'),
	 (2,'продан'),
	 (3,'бронь');
