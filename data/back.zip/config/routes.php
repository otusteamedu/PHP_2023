<?php

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Loader\Configurator\RoutingConfigurator;

return function (RoutingConfigurator $routes): void {
    $routes
        ->add('index', '/')->controller([\App\Common\Infrastructure\Controller::class, 'index'])->methods(['GET'])
        ->add('order_list', '/order')->controller([\App\Ads\Infrastructure\Controller::class, 'index'])->methods(['GET'])
        ->add('order_post', '/order')->controller([\App\Ads\Infrastructure\Controller::class, 'create'])->methods(['POST']);
};