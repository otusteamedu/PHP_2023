<?php

namespace App\Common\Infrastructure\Http;

class Controller
{
    public function get(): string
    {
        return 'Hello world123';
    }
}
