<?php

namespace App\Ads\Domain;

use Symfony\Component\Validator\Constraints\NotBlank;

class Ad
{
    private ?int   $id;

    /**
     * @var string
     * @Assert\NotBlank (message="Name cannot be empty")
     */
    private string $name;

    /**
     * @var string
     * @Assert\NotBlank (message="Email cannot be empty")
     */
    #[NotBlank()]
    private string $email;
    private string $phone;
    private string $title;
    private string $comment;
    private array  $photo;
    private Status $status = Status::NEW;

    public function __construct(

    )
    {
    }

    /**
     * @return int|null
     */
    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return string
     * @Assert\NotBlank (message="Name cannot be empty")
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * @return string
     */
    public function getEmail(): string
    {
        return $this->email;
    }

    /**
     * @return string
     */
    public function getPhone(): string
    {
        return $this->phone;
    }

    /**
     * @return string
     */
    public function getComment(): string
    {
        return $this->comment;
    }

    /**
     * @return array
     */
    public function getPhoto(): array
    {
        return $this->photo;
    }

    /**
     * @return Status
     */
    public function getStatus(): Status
    {
        return $this->status;
    }

    /**
     * @return string
     */
    public function getTitle(): string
    {
        return $this->title;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function setName(string $name): void
    {
        $this->name = $name;
    }

    public function setEmail(string $email): void
    {
        $this->email = $email;
    }

    public function setPhone(string $phone): void
    {
        $this->phone = $phone;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function setComment(string $comment): void
    {
        $this->comment = $comment;
    }

    public function setPhoto(array $photo): void
    {
        $this->photo = $photo;
    }

    public function setStatus(Status $status): void
    {
        $this->status = $status;
    }

//    public static function loadValidatorMetadata(ClassMetadata $metadata): void
//    {
//        $metadata->addPropertyConstraint('name', new NotBlank());
//
//        $metadata->addPropertyConstraint('email', new NotBlank());
//        $metadata->addPropertyConstraint('email', new Email());
//
//        $metadata->addPropertyConstraint('phone', new NotBlank());
//
//        $metadata->addPropertyConstraint('title', new NotBlank());
//
//        $metadata->addPropertyConstraint('photo', new Image());
//
//        $metadata->addPropertyConstraint('status', new NotBlank());
//    }
}