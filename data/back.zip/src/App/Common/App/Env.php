<?php

namespace App\Common\App;

use Dotenv\Dotenv;

class Env
{
    use \App\Singleton;

    public function __construct()
    {
        $dotenv = Dotenv::createImmutable(__DIR__ . '/../../../../');
        $dotenv->load();
    }

    public function get(string $key): string
    {
        return $_ENV[$key];
    }
}
