<?php
namespace App\Ads\Infrastructure;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class Controller extends AbstractController
{
    public function create(
        \Symfony\Component\HttpFoundation\Request $request
    ): JsonResponse
    {
        // Создаем OrderCreateRequest
        // Проверяем валидность
        // Создаем Order
//        var_dump($request);
//        $arResult = [];

//        $request = \Symfony\Component\HttpFoundation\Request::createFromGlobals();
//        $post = $request->request->all();
//        $files = $request->files->all();
//
//        $ad = new Ad();
//
//        $validator = Validation::createValidator();
//
//        $validation = $validator->validate($ad);
//        var_dump($validation);

//        $validation->validate();

//        if ($validation->fails()) {
//            $arResult['errors'] = $validation->errors()->toArray();
//        } else {
//
//        }

        // Создаем OrderCreateRequest
        // Проверяем валидность
        // Создаем Order

//        SimpleRouter::response()->json($arResult);
        return (new JsonResponse([]));
    }

    public function index(): Response
    {
//        $ad = new Ad();
//        $form = $this->createFormBuilder($ad)
//            ->add('task', TextType::class)
//            ->add('dueDate', DateType::class)
//            ->add('save', SubmitType::class, ['label' => 'Create Task'])
//            ->getForm();

        return new Response('Hello world');
    }

    public function getById(int $id):string
    {
        return '';
    }
}