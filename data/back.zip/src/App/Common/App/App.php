<?php

namespace App\Common\App;

use App\Common\Infrastructure\Cli\Commander;
use App\Common\Infrastructure\Http\Router;
use App\Singleton;
use Exception;
use Pecee\Http\Middleware\Exceptions\TokenMismatchException;
use Pecee\SimpleRouter\Exceptions\HttpException;
use Pecee\SimpleRouter\Exceptions\NotFoundHttpException;
use Psr\Container\ContainerInterface;

class App
{
    use Singleton;

    private Router $router;
    private ContainerInterface $container;
    /**
     * @var Commander
     */
    private Commander $commander;

    /**
     * @throws Exception
     */
    public function __construct()
    {
        $this->createContainer();
        $this->createRouter();
    }

    /**
     * @throws HttpException
     * @throws NotFoundHttpException
     * @throws TokenMismatchException
     */
    public function start(array $args = []): void
    {
        $this->router->start();
    }

    /**
     * @return mixed
     */
    public function getContainer(): ContainerInterface
    {
        return $this->container;
    }

    /**
     * @throws Exception
     */
    private function createContainer(): void
    {
        $builder = new \DI\ContainerBuilder();
        $path = realpath(realpath(__DIR__ . '/../../../../di.php'));
        $builder->addDefinitions($path);
        $this->container = $builder->build();
    }

    public function createRouter():void
    {
        $this->router = Router::getInstance();
    }

    /**
     * @return Router
     */
    public function getRouter(): Router
    {
        return Router::getInstance();
    }

    public function getDocumentRoot(): string
    {
        return __DIR__ . '/../../../../';
    }
}
